﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace yy.blog.file
{
    public enum FileTypes
    {
        Other = 0,
        图片 = 1,
        文本文件 = 2,
        Excel = 3,
        压缩包文件=4

    }
}
